'use client'

import { useState } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import CollectionForm from './CollectionForm'
import DataTable from './DataTable'
import { CommissionEntry } from '@/types/types'

type CollectionTabsProps = {
  onSubmit: (data: Omit<CommissionEntry, 'id' | 'createdAt' | 'updatedAt'>) => void
  data: CommissionEntry[]
}

export default function CollectionTabs({ onSubmit, data }: CollectionTabsProps) {
  return (
    <Tabs defaultValue="form" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="form">Collection Form</TabsTrigger>
        <TabsTrigger value="table">Data Table</TabsTrigger>
      </TabsList>
      <TabsContent value="form">
        <CollectionForm onSubmit={onSubmit} />
      </TabsContent>
      <TabsContent value="table">
        <DataTable data={data} />
      </TabsContent>
    </Tabs>
  )
}

